/*Student Management System
- Learner will be learning how to add new students to the database, how to generate a 5 digit unique
studentID for each student, how to enroll students in the given courses. Also, you will be
implementing the following operations enroll, view balance, pay tuition fees, show status, etc. The
status will show all the details of the student including name, id, courses enrolled and balance.*/




package StudentManageMent;

public class StudentSource {
     
	    private String name;
	    private int id;
	    private long phnNum;
	    private String StuCourse;
		private String abt;
		private double amount;
		private double balance;
	

		public String getName() {
			return name;
		}


		public void setName(String name) {
			this.name = name;
		}


		public int getId() {
			return id;
		}


		public void setId(int id) {
			this.id = id;
		}


		public long getPhnNum() {
			return phnNum;
		}


		public void setPhnNum(long phnNum) {
			this.phnNum = phnNum;
		}


		public String getStuCourse() {
			return StuCourse;
		}


		public void setStuCourse(String stuCourse) {
			StuCourse = stuCourse;
		}


		public String getAbt() {
			return abt;
		}


		public void setAbt(String abt) {
			this.abt = abt;
		}


		public double getAmount() {
			return amount;
		}


		public void setAmount(double amount) {
			this.amount = amount;
		}


		public double getBalance() {
			return balance;
		}


		public void setBalance(double balance) {
			this.balance = balance;
		}


		public static void main(String[] args) {
	}

}
