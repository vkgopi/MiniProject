
package StudentManageMent;

import java.util.Scanner;

public class StudentMain extends StudentSource {
	double t;

	public double getT() {
		return t;
	}

	public void setT(double t) {
		this.t = t;
	}

	public static void main(String[] args) {
		
		//creating a loop for multiple student
		for(int i=1;i<=5;i++)
		{
		Scanner sc=new Scanner(System.in);
		
        //creating new main 
		StudentMain m=new StudentMain();
		
		System.out.println("Admission"+" "+i);
		System.out.println("Welcome to School of Coding");
		
		//entering student name
		System.out.println("\nEnter your name");
		m.setName(sc.nextLine());
		
		//entering student phone number
		System.out.println("Enter your phone number");
		m.setPhnNum(sc.nextLong());
		
		//Assigning fixed id for student
		m.setId(2023);
		
		//availability of course
		System.out.println("\n");
		System.out.println("Programming Courses");
		System.out.println("-------");
		System.out.println("Courses we have..");
		System.out.println("1.Java");
		System.out.println("2.C & C++");
		System.out.println("3.Python");
		System.out.println("Which Course do u want to Select?");
		
		//creating switch case to implement the student details
		int ch;
		ch=sc.nextInt();
		switch(ch)
		{
		case 1:
		{
			        //enrolling a student course
			        m.setStuCourse("Hii"+" "+m.getName()+","+" you choosed a Java course");
					System.out.println(m.getStuCourse());
					
					//about the course
					m.setAbt("This is 8 month course" );
					System.out.println(m.getAbt());
					
					//Total price of the course
					m.setAmount(20000);
					System.out.println("Price of the course is:"+m.getAmount());
					
					//the amount student should pay
					System.out.println("How much amount you are going to pay now"+" "+m.getName()+"?");
					m.setBalance(sc.nextInt());
					
					//total price - student paid price
					m.setT(m.getAmount()-m.getBalance());
					System.out.println("Successfully enrolled your course\n");
					
					//print the student name,id,total balance, remaining balance,phone number 
					System.out.println("Name of the Student:"+m.getName());
					System.out.println("Student id:"+m.getId()+i);
					System.out.println("Student PhnNumber:"+m.getPhnNum());
					System.out.println("The Amount you paid:"+m.getBalance());
					
					//check the amount 
					if(m.getBalance()==20000)
					{
						System.out.println("You paid Full Amount");
					}else {
					System.out.println("Remaining amount you have to pay:"+m.getT());
					}
					
					System.out.println("All the best"+" "+m.getName()+"!!");
					break;
		}
		case 2:
		{
			        m.setStuCourse("Hii"+" "+m.getName()+","+" you choose a C & C++ course");
					System.out.println(m.getStuCourse());
					m.setAbt("This is 4 month course" );
					System.out.println(m.getAbt());
					m.setAmount(10000);
					System.out.println("Price of the course is:"+m.getAmount());
					System.out.println("How much amount you are going to pay now"+" "+m.getName()+"?");
					m.setBalance(sc.nextInt());
					m.setT(m.getAmount()-m.getBalance());
					System.out.println("Successfully enrolled your course\n");
					System.out.println("Name of the Student:"+m.getName());
					System.out.println("Student id:"+m.getId()+i);
					System.out.println("Student PhnNumber:"+m.getPhnNum());
					System.out.println("The Amount you paid:"+m.getBalance());
					if(m.getBalance()==10000)
					{
						System.out.println("You paid Full Amount");
					}else {
					System.out.println("Remaining amount you have to pay:"+m.getT());
					}
					System.out.println("All the best"+" "+m.getName()+"!!");
					break;
		}
		case 3:
		{
			        m.setStuCourse("Hii"+" "+m.getName()+","+" you choose a python course");
					System.out.println(m.getStuCourse());
					m.setAbt("This is 6 month course" );
					System.out.println(m.getAbt());
					m.setAmount(15000);
					System.out.println("Price of the course is:"+m.getAmount());
					System.out.println("How much amount you are going to pay now"+" "+m.getName()+"?");
					m.setBalance(sc.nextInt());
					m.setT(m.getAmount()-m.getBalance());
					System.out.println("Successfully enrolled your course\n");
					System.out.println("Name of the Student:"+m.getName());
					System.out.println("Student id:"+m.getId()+i);
					System.out.println("Student PhnNumber:"+m.getPhnNum());
					System.out.println("The Amount you paid:"+m.getBalance());
					if(m.getBalance()==15000)
					{
						System.out.println("You paid Full Amount");
					}
					else {
					System.out.println("Remaining amount you have to pay:"+m.getT());
					}
					System.out.println("All the best"+" "+m.getName()+"!!");
					break;
		}
		default:
		{
			System.out.println("Sorry"+" "+m.getName()+","+"this course is Not Available");
			break;
		}
	}
		System.out.println("Thank you for your interest");
		System.out.println("------------------------------\n");
}}}